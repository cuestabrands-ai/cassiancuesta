const CACHE = 'cassian-v4';
const ASSETS = [
  '/', '/index.html', '/numberblocks.html', '/games.html',
  '/chess.html', '/jokes.html', '/cosmo.html', '/bitcoin.html',
  '/books.html', '/puzzles.html', '/learning-path.html',
  '/focus.html', '/world.html', '/manifest.json',
  '/cassian-profile.js', '/cosmo-hints.js'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  // Don't cache API calls
  if (e.request.url.includes('anthropic') || e.request.url.includes('workers.dev')) return;
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(res => {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      }).catch(() => cached || new Response('Offline', { status: 503 }));
    })
  );
});
